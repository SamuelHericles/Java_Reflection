package br.com.alura.alurator.protocolo;

public class Request {
	
	public Request(String url) {
	}
}
