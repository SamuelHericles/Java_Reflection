package br.com.alura.alurator;

public class Alurator {
	
	public Object executa(String url) {
		// TODO - processa a requisicao executando o metodo
		// da classe em questao
		
		return null;
	}
}
